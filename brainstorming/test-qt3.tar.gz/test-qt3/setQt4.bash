#!/bin/bash

 sudo update-alternatives --set qmake     /usr/bin/qmake-qt4
 sudo update-alternatives --set uic       /usr/bin/uic-qt4
 sudo update-alternatives --set designer  /usr/bin/designer-qt4
 sudo update-alternatives --set assistant /usr/bin/assistant-qt4
 sudo update-alternatives --set qtconfig  /usr/bin/lrelease-qt4
 sudo update-alternatives --set moc       /usr/bin/moc-qt4
 sudo update-alternatives --set lupdate   /usr/bin/lupdate-qt4
 sudo update-alternatives --set lrelease  /usr/bin/lrelease-qt4
#sudo update-alternatives --set linguist  /usr/bin/lrelease-qt4