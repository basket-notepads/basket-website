#include "basket.h"

#include <QGraphicsScene>
#include <QTextDocument>
#include <QList>

Note::Note(const QString &text, QGraphicsItem *parent, QGraphicsScene *scene)
 : QGraphicsTextItem(text, parent, scene)
{
}

int Note::type() const
{
	return QGraphicsItem::UserType + 1;
}

BasketView::BasketView(QWidget *parent)
 : QGraphicsView(new QGraphicsScene(), parent)
{
	setAlignment(Qt::AlignLeft | Qt::AlignTop); // Do not center the scene if it is smaller than the viewport

	for (int i = 0; i < 10; i++) {
		Note *note = new Note("An example of text note!!!", 0, scene());
		note->setTextInteractionFlags(Qt::TextEditorInteraction);
		m_notes.append(note);
		connect( note->document(), SIGNAL(contentsChanged()), this, SLOT(relayoutNotes()) );
	}
};

void BasketView::relayoutNotes()
{
	qreal height = 0.0;
	foreach (Note *note, m_notes) {
		note->setTextWidth(scene()->width() - 1); // - 1 to display the whole focused-text-edit rectangle
		note->setPos(0, height);
		height += note->boundingRect().height();
	}
	scene()->setSceneRect(0, 0, viewport()->width(), height + 1); // + 1 to display the whole focused-text-edit rectangle
}

void BasketView::resizeEvent(QResizeEvent *event)
{
	QGraphicsView::resizeEvent(event);
	scene()->setSceneRect(0, 0, viewport()->width(), scene()->sceneRect().height());
	relayoutNotes();
}
