#!/bin/bash

 sudo update-alternatives --set qmake     /usr/bin/qmake-qt3
 sudo update-alternatives --set uic       /usr/bin/uic-qt3
 sudo update-alternatives --set designer  /usr/bin/designer-qt3
 sudo update-alternatives --set assistant /usr/bin/assistant-qt3
 sudo update-alternatives --set qtconfig  /usr/bin/lrelease-qt3
 sudo update-alternatives --set moc       /usr/bin/moc-qt3
 sudo update-alternatives --set lupdate   /usr/bin/lupdate-qt3
 sudo update-alternatives --set lrelease  /usr/bin/lrelease-qt3
#sudo update-alternatives --set linguist  /usr/bin/lrelease-qt4