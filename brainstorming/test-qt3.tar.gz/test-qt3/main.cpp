#include <qapplication.h>

#include "basket.h"

int main(int argc, char **argv)
{
	QApplication app(argc, argv);

	BasketView basket;
	basket.resize(700, 500);
	basket.setCaption("BasKet Forever, for KDE 4");
	basket.show();

	app.setMainWidget(&basket);
	return app.exec();
}
