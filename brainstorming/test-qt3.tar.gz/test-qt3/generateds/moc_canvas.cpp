/****************************************************************************
** Meta object code from reading C++ file 'canvas.h'
**
** Created: Sun Apr 15 12:50:27 2007
**      by: The Qt Meta Object Compiler version 59 (Qt 4.2.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../canvas.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'canvas.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.2.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_FigureEditor[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // signals: signature, parameters, type, tag, flags
      14,   13,   13,   13, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_FigureEditor[] = {
    "FigureEditor\0\0status(QString)\0"
};

const QMetaObject FigureEditor::staticMetaObject = {
    { &QGraphicsView::staticMetaObject, qt_meta_stringdata_FigureEditor,
      qt_meta_data_FigureEditor, 0 }
};

const QMetaObject *FigureEditor::metaObject() const
{
    return &staticMetaObject;
}

void *FigureEditor::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_FigureEditor))
	return static_cast<void*>(const_cast<FigureEditor*>(this));
    return QGraphicsView::qt_metacast(_clname);
}

int FigureEditor::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGraphicsView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: status((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        }
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void FigureEditor::status(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
static const uint qt_meta_data_Main[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // slots: signature, parameters, type, tag, flags
       6,    5,    5,    5, 0x0a,
      13,    5,    5,    5, 0x08,
      23,    5,    5,    5, 0x08,
      33,    5,    5,    5, 0x08,
      41,    5,    5,    5, 0x08,
      48,    5,    5,    5, 0x08,
      60,    5,    5,    5, 0x08,
      72,    5,    5,    5, 0x08,
      85,    5,    5,    5, 0x08,
      98,    5,    5,    5, 0x08,
     110,    5,    5,    5, 0x08,
     120,    5,    5,    5, 0x08,
     130,    5,    5,    5, 0x08,
     145,    5,    5,    5, 0x08,
     155,    5,    5,    5, 0x08,
     165,    5,    5,    5, 0x08,
     180,    5,    5,    5, 0x08,
     190,    5,    5,    5, 0x08,
     199,    5,    5,    5, 0x08,
     217,    5,    5,    5, 0x08,
     242,    5,    5,    5, 0x08,
     251,    5,    5,    5, 0x08,
     261,    5,    5,    5, 0x08,
     270,    5,    5,    5, 0x08,
     278,    5,    5,    5, 0x08,
     286,    5,    5,    5, 0x08,
     294,    5,    5,    5, 0x08,
     302,    5,    5,    5, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_Main[] = {
    "Main\0\0help()\0aboutQt()\0newView()\0clear()\0init()\0addSprite()\0"
    "addCircle()\0addHexagon()\0addPolygon()\0addSpline()\0addText()\0"
    "addLine()\0addRectangle()\0addMesh()\0addLogo()\0addButterfly()\0"
    "enlarge()\0shrink()\0rotateClockwise()\0rotateCounterClockwise()\0"
    "zoomIn()\0zoomOut()\0mirror()\0moveL()\0moveR()\0moveU()\0moveD()\0"
    "print()\0"
};

const QMetaObject Main::staticMetaObject = {
    { &Q3MainWindow::staticMetaObject, qt_meta_stringdata_Main,
      qt_meta_data_Main, 0 }
};

const QMetaObject *Main::metaObject() const
{
    return &staticMetaObject;
}

void *Main::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Main))
	return static_cast<void*>(const_cast<Main*>(this));
    return Q3MainWindow::qt_metacast(_clname);
}

int Main::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3MainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: help(); break;
        case 1: aboutQt(); break;
        case 2: newView(); break;
        case 3: clear(); break;
        case 4: init(); break;
        case 5: addSprite(); break;
        case 6: addCircle(); break;
        case 7: addHexagon(); break;
        case 8: addPolygon(); break;
        case 9: addSpline(); break;
        case 10: addText(); break;
        case 11: addLine(); break;
        case 12: addRectangle(); break;
        case 13: addMesh(); break;
        case 14: addLogo(); break;
        case 15: addButterfly(); break;
        case 16: enlarge(); break;
        case 17: shrink(); break;
        case 18: rotateClockwise(); break;
        case 19: rotateCounterClockwise(); break;
        case 20: zoomIn(); break;
        case 21: zoomOut(); break;
        case 22: mirror(); break;
        case 23: moveL(); break;
        case 24: moveR(); break;
        case 25: moveU(); break;
        case 26: moveD(); break;
        case 27: print(); break;
        }
        _id -= 28;
    }
    return _id;
}
