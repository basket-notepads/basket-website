#ifndef BASKET_H
#define BASKET_H

#include <QGraphicsView>
#include <QGraphicsItem>
#include <QList>

class Note : public QGraphicsTextItem
{
  public:
	Note(const QString &text, QGraphicsItem *parent = 0, QGraphicsScene *scene = 0);
	int type() const;
};

class BasketView : public QGraphicsView
{
  Q_OBJECT
  public:
	BasketView(QWidget *parent = 0);
  public slots:
	void relayoutNotes();
  protected:
	void resizeEvent(QResizeEvent *event);
  private:
	QList<Note*> m_notes;
};

#endif // BASKET_H
